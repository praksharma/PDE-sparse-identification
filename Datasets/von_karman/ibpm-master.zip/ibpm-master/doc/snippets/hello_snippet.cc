int i = 7;
std::cout << "Hello world!" << std::endl;
std::cout << "i is " << i << std::endl;