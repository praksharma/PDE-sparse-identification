This directory contains examples written using the Gmsh Application Programming
Interface (API), in C++, C, Python and Julia.

To learn how to use the Gmsh API, first check out the `python', `julia', `c++'
and `c' subdirectories of `gmsh/tutorial': these subdirectories contain Python,
Julia, C++ and C versions of (some of) the `.geo' tutorials, as well as detailed
instructions on how to run the examples (and compile the C++ and C files).
